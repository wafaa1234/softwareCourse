<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Nexmo;
use GuzzleHttp\Client;

class SendSMSController extends Controller
{
    public function sendSMS(Request $request , $mobile_no)
    {

        $message = Nexmo::message()->send([
            'to' => $mobile_no,
            'from' => 'Shopping Light',
            'text' => 'I will go to the hospital : current location of the patient' . $this->getGPS($request)['city']
        ]);
    }

    public function getGPS(Request $request) 
    {
   
        $client = new Client();

        $res = $client->request('GET', 'http://ip-api.com/json');

        $stringData = json_decode($res->getBody(), true);

        return $stringData;

    }
    public function getMap(Request $request)
    {
    	 $client = new Client();
    	  $res = $client->get('https://maps.googleapis.com/maps/api/place/nearbysearch/json?location='.$this->getGPS($request)['lat'].','.$this->getGPS($request)['lon'].'&radius=35000&types=hospital&name=cruise&key=AIzaSyAruSAj9XPFSf2aDMUag39O-81FnLeP_A0');
    	   $data =  json_decode($res->getBody(), true);
    	   return $data['results'];
    }

}
